# Analisador Sintático CSmall
Trabalho da disciplina de Compiladores (2018/1)

Para executar:
```
python3 main.py
```

Em seguida, digite o nome do arquivo que deseja analisar.

Arquivo de teste para exemplo: teste1.c
